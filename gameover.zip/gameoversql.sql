create database gameover;
use gameover;
create table usuarios (
    id bigint auto_increment primary key,
    nombre varchar(10) not null,
    email varchar(255) unique not null,
    password varchar(255) not null,
    rol varchar(50)
);

create table games (
    id bigint auto_increment primary key,
    titulo varchar(255) not null,
    genero varchar(255),
    precio double,
    descripcion text,
    imagen varchar(500),
    stock integer
);

