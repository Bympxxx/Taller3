package com.gameover.controller;

import com.gameover.entity.Torneo;
import com.gameover.service.TorneoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/torneos")
public class TorneoController {

    @Autowired private TorneoServicio torneoServicio;

    @GetMapping
    public List<Torneo> getAll() { return torneoServicio.getAll(); }

    @GetMapping("/{id}")
    public Torneo getById(@PathVariable Long id) { return torneoServicio.getById(id); }

    @PostMapping("/guardartorneo")
    public Torneo crear(@RequestBody Torneo torneo) { return torneoServicio.crear(torneo); }

    @PutMapping("/actualizartorneo/{id}")
    public Torneo actualizar(@PathVariable Long id, @RequestBody Torneo torneo) {
        return torneoServicio.actualizar(id, torneo);
    }

    @DeleteMapping("/eliminartorneo/{id}")
    public void eliminar(@PathVariable Long id) { torneoServicio.eliminar(id); }
}