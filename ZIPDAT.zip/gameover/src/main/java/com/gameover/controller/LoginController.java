package com.gameover.controller;

import com.gameover.entity.Usuario;
import com.gameover.service.UsuarioServicio;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
@CrossOrigin(origins = "http://localhost:4200")
public class LoginController {

    private final UsuarioServicio usuarioServicio;
    private final BCryptPasswordEncoder passwordEncoder;

    public LoginController(UsuarioServicio usuarioServicio, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioServicio = usuarioServicio;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario usuario) {
        return usuarioServicio.buscarPorEmail(usuario.getEmail())
                .map(u -> {
                    if (passwordEncoder.matches(usuario.getPassword(), u.getPassword())) {
                        return ResponseEntity.ok((Object) u);
                    } else {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                                .body((Object) "Contraseña incorrecta");
                    }
                })
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Usuario no encontrado"));
    }

    @PostMapping("/registro")
    public ResponseEntity<?> registro(@RequestBody Usuario usuario) {
        if (usuarioServicio.buscarPorEmail(usuario.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("El email ya está registrado");
        }
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        return ResponseEntity.ok(usuarioServicio.guardarUsuario(usuario));
    }
}