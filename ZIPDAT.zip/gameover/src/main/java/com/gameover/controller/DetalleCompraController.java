package com.gameover.controller;

import com.gameover.entity.*;
import com.gameover.service.DetalleCompraServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/detalleCompra")
@CrossOrigin(origins = "*")
public class DetalleCompraController {

    @Autowired private DetalleCompraServicio detalleCompraServicio;

    @GetMapping("/porCompra/{compraId}")
    public List<DetalleCompra> getByCompra(@PathVariable Long compraId) {
        return detalleCompraServicio.getByCompra(compraId);
    }
}