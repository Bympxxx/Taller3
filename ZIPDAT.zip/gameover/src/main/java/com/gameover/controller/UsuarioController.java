package com.gameover.controller;

import com.gameover.entity.Usuario;
import com.gameover.service.UsuarioServicio;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
@CrossOrigin(origins = "http://localhost:4200")
public class UsuarioController {

    private final UsuarioServicio usuarioServicio;

    public UsuarioController(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

    @GetMapping
    public ResponseEntity<List<Usuario>> getUsuarios() {
        return ResponseEntity.ok(usuarioServicio.getUsuarios());
    }

    @PostMapping("/guardarUsuario")
    public ResponseEntity<Usuario> postUsuario(@RequestBody Usuario usuario) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(usuarioServicio.guardarUsuario(usuario));
    }

    @PutMapping("/actualizarUsuario/{id}")
    public ResponseEntity<Usuario> putUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        return ResponseEntity.ok(usuarioServicio.actualizarUsuario(id, usuario));
    }

    @DeleteMapping("/eliminarUsuario/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Long id) {
        usuarioServicio.buscarUsuarioPorId(id)
                .orElseThrow(() -> new RuntimeException("Usuario no existe"));
        usuarioServicio.eliminarUsuario(id);
        return ResponseEntity.noContent().build();
    }
}