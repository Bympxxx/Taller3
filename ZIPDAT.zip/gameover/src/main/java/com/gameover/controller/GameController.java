package com.gameover.controller;

import com.gameover.entity.Game;
import com.gameover.service.GameServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/games")
@CrossOrigin(origins = "http://localhost:4200")
public class GameController {

    @Autowired
    private GameServicio gameServicio;

    @GetMapping
    public ResponseEntity<List<Game>> getGames() {
        return ResponseEntity.ok(gameServicio.leerGames());
    }

    @PostMapping("/guardarGame")
    public ResponseEntity<Game> postGame(@RequestBody Game game) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(gameServicio.guardarGame(game));
    }

    @PutMapping("/actualizarGame/{id}")
    public ResponseEntity<Game> putGame(@PathVariable Long id, @RequestBody Game game) {
        return ResponseEntity.ok(gameServicio.actualizarGame(id, game));
    }

    @DeleteMapping("/eliminarGame/{id}")
    public ResponseEntity<Void> deleteGame(@PathVariable Long id) {
        gameServicio.eliminarGame(id);
        return ResponseEntity.noContent().build();
    }
}