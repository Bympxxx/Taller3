package com.gameover.role;

public enum Rol {
    ADMIN,
    USER

}
