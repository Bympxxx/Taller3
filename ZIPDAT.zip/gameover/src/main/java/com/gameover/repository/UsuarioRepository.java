package com.gameover.repository;

import com.gameover.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Buscar usuario por email y password
    Optional<Usuario> findByEmailAndPassword(String email, String password);

    // Alternativa más segura: buscar solo por email
    Optional<Usuario> findByEmail(String email);
}