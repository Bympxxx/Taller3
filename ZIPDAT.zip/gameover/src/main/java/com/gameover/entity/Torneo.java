package com.gameover.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "torneos")
public class Torneo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String descripcion;
    private String juego;
    private String imagen;
    private String fechaInicio;
    private String fechaFin;
    private Integer maxParticipantes;
    private Double premioPrincipal;
    private String estado;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getJuego() { return juego; }
    public void setJuego(String juego) { this.juego = juego; }
    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }
    public String getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(String fechaInicio) { this.fechaInicio = fechaInicio; }
    public String getFechaFin() { return fechaFin; }
    public void setFechaFin(String fechaFin) { this.fechaFin = fechaFin; }
    public Integer getMaxParticipantes() { return maxParticipantes; }
    public void setMaxParticipantes(Integer maxParticipantes) { this.maxParticipantes = maxParticipantes; }
    public Double getPremioPrincipal() { return premioPrincipal; }
    public void setPremioPrincipal(Double premioPrincipal) { this.premioPrincipal = premioPrincipal; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}