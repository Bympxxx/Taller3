package com.gameover.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "games")
public class Game {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false)
    private String genero;

    @Column(nullable = false)
    private Double precio;

    private String descripcion;
    private String imagen;
    private Integer stock;
    private Double rating;
    private String platform;
    private Integer releaseYear;
}