package com.gameover.service;

import com.gameover.entity.Torneo;
import com.gameover.repository.TorneoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TorneoServicio {

    @Autowired private TorneoRepository torneoRepository;

    public List<Torneo> getAll() { return torneoRepository.findAll(); }

    public Torneo getById(Long id) {
        return torneoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Torneo no encontrado"));
    }

    public Torneo crear(Torneo torneo) { return torneoRepository.save(torneo); }

    public Torneo actualizar(Long id, Torneo datos) {
        Torneo t = getById(id);
        t.setNombre(datos.getNombre());
        t.setDescripcion(datos.getDescripcion());
        t.setJuego(datos.getJuego());
        t.setImagen(datos.getImagen());
        t.setFechaInicio(datos.getFechaInicio());
        t.setFechaFin(datos.getFechaFin());
        t.setMaxParticipantes(datos.getMaxParticipantes());
        t.setPremioPrincipal(datos.getPremioPrincipal());
        t.setEstado(datos.getEstado());
        return torneoRepository.save(t);
    }

    public void eliminar(Long id) { torneoRepository.deleteById(id); }
}