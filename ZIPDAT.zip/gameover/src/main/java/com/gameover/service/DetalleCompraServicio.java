package com.gameover.service;

import com.gameover.entity.*;
import com.gameover.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class DetalleCompraServicio {

    @Autowired private DetalleCompraRepository detalleCompraRepository;
    @Autowired private GameRepository gameRepository;

    public DetalleCompra guardar(Long gameId, Integer cantidad, Long compraId) {
        Game game = gameRepository.findById(gameId)
                .orElseThrow(() -> new RuntimeException("Juego no encontrado"));

        DetalleCompra detalle = new DetalleCompra();
        detalle.setCompraId(compraId);
        detalle.setGame(game);
        detalle.setCantidad(cantidad);
        detalle.setPrecioUnitario(game.getPrecio());
        return detalleCompraRepository.save(detalle);
    }

    public List<DetalleCompra> getByCompra(Long compraId) {
        return detalleCompraRepository.findByCompraId(compraId);
    }
}