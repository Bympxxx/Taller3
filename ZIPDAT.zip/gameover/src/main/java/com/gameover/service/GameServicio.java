package com.gameover.service;

import com.gameover.entity.Game;
import com.gameover.repository.GameRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GameServicio {

    private final GameRepository gameRepository;

    public GameServicio(GameRepository gameRepository) {
        this.gameRepository = gameRepository;
    }

    // Listar todos los juegos
    public List<Game> leerGames() {
        return gameRepository.findAll();
    }

    // Guardar un nuevo juego
    public Game guardarGame(Game game) {
        return gameRepository.save(game);
    }

    // Actualizar un juego existente
    public Game actualizarGame(Long id, Game game) {
        Game gameEncontrado = buscarGamePorId(id)
                .orElseThrow(() -> new RuntimeException("Game no existe"));

        gameEncontrado.setTitulo(game.getTitulo());
        gameEncontrado.setGenero(game.getGenero());
        gameEncontrado.setPrecio(game.getPrecio());

        return gameRepository.save(gameEncontrado);
    }

    // Eliminar un juego
    public void eliminarGame(Long id) {
        Game gameEncontrado = buscarGamePorId(id)
                .orElseThrow(() -> new RuntimeException("Game no existe"));
        gameRepository.delete(gameEncontrado);
    }

    // Buscar un juego por ID
    public Optional<Game> buscarGamePorId(Long id) {
        return gameRepository.findById(id);
    }
}