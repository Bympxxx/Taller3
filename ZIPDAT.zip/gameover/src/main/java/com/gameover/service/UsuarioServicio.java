package com.gameover.service;

import com.gameover.entity.Usuario;
import com.gameover.repository.UsuarioRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioServicio {

    private final UsuarioRepository usuarioRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UsuarioServicio(UsuarioRepository usuarioRepository, BCryptPasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<Usuario> getUsuarios() {
        return usuarioRepository.findAll();
    }

    public Usuario guardarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Usuario actualizarUsuario(Long id, Usuario usuario) {
        Usuario encontrado = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no existe"));

        encontrado.setEmail(usuario.getEmail());
        encontrado.setNombre(usuario.getNombre());
        encontrado.setRol(usuario.getRol());


        if (usuario.getPassword() != null && !usuario.getPassword().isBlank()) {
            encontrado.setPassword(passwordEncoder.encode(usuario.getPassword()));
        }

        if (usuario.getPlan() != null) {
            encontrado.setPlan(usuario.getPlan());
        }

        return usuarioRepository.save(encontrado);
    }

    public void eliminarUsuario(Long id) {
        Usuario encontrado = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no existe"));
        usuarioRepository.delete(encontrado);
    }

    public Optional<Usuario> buscarUsuarioPorId(Long id) {
        return usuarioRepository.findById(id);
    }

    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }
}