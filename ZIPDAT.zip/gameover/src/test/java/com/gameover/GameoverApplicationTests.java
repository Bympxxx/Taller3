package com.gameover;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameoverApplicationTests {

	@Test
	void contextLoads() {
	}

}
